const images = {
  arrow: require("./arrow.png"),
  authenBG: require("./authenBG.png"),
  back: require("./back.png"),
  calendar: require("./calendar.png"),
  facebook: require("./facebook.png"),
  google: require("./google.png"),
  key: require("./key.png"),
  noImage: require("./no-image.jpg"),
  twitter: require("./twitter.png"),
  userBG: require("./userBG.png"),
  Vector: require("./Vector.png"),
};

export default images;
