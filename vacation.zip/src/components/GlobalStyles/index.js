export { default } from "./GlobalStyles";
