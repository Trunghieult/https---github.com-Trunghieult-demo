import styles from "./Album.module.scss";
import classNames from "classnames/bind";

const cx = classNames.bind(styles);

const Album = () => {
  return <div></div>;
};

export default Album;
