import styles from "./AlbumUser.module.scss";
import classNames from "classnames/bind";
const cx = classNames.bind(styles);

const AlbumUser = () => {
  return <div className={cx("wrapper")}>AlbumUser</div>;
};

export default AlbumUser;
